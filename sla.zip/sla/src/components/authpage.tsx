import React, { useState, FormEvent, ChangeEvent } from 'react';
import { 
  Container, 
  Typography, 
  TextField, 
  Button, 
  Paper, 
  Box, 
  Link, 
  Tabs, 
  Tab, 
  IconButton, 
  InputAdornment 
} from '@mui/material';
import { 
  Visibility, 
  VisibilityOff, 
  LockOpen, 
  Email, 
  Person 
} from '@mui/icons-material';
import { blue, grey } from '@mui/material/colors';

interface AuthPageProps {
  onLogin: (user: { id: string; username: string; email: string }) => void;
}

interface FormData {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLogin }) => {
  const [activeTab, setActiveTab] = useState<number>(0);
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [formData, setFormData] = useState<FormData>({
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (activeTab === 0) {
      // Simplified login logic
      onLogin({
        id: '1', 
        username: formData.email.split('@')[0], 
        email: formData.email
      });
    } else {
      // Signup logic
      if (formData.password !== formData.confirmPassword) {
        alert('Passwords do not match');
        return;
      }
      onLogin({
        id: '1', 
        username: formData.username, 
        email: formData.email
      });
    }
  };

  const handleTabChange = (_e: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleMouseDownPassword = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
  };

  return (
    <Container maxWidth="xs" sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      alignItems: 'center', 
      justifyContent: 'center', 
      height: '100vh',
      backgroundColor: grey[50]
    }}>
      <Paper 
        elevation={6} 
        sx={{ 
          padding: 4, 
          display: 'flex', 
          flexDirection: 'column', 
          alignItems: 'center',
          width: '100%'
        }}
      >
        <Typography 
          variant="h4" 
          sx={{ 
            mb: 3, 
            color: blue[700], 
            fontWeight: 600 
          }}
        >
          SLA Management
        </Typography>

        <Tabs 
          value={activeTab} 
          onChange={handleTabChange}
          centered
          sx={{ mb: 3, width: '100%' }}
        >
          <Tab label="Login" />
          <Tab label="Sign Up" />
        </Tabs>

        <Box 
          component="form" 
          onSubmit={handleSubmit} 
          sx={{ width: '100%' }}
        >
          {activeTab === 1 && (
            <TextField
              fullWidth
              margin="normal"
              label="Username"
              name="username"
              value={formData.username}
              onChange={handleChange}
              required
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Person />
                  </InputAdornment>
                )
              }}
            />
          )}

          <TextField
            fullWidth
            margin="normal"
            label="Email"
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            InputProps={{
              startAdornment: <InputAdornment position="start">
                  <Email />
                
              </InputAdornment>
            }}
          />

          <TextField
            fullWidth
            margin="normal"
            label="Password"
            type={showPassword ? "text" : "password"}
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <LockOpen />
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton 
                    aria-label="toggle password visibility"
                    onClick={handleClickShowPassword}
                    onMouseDown={handleMouseDownPassword}
                    edge="end"
                  >
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              )
            }}
          />

          {activeTab === 1 && (
            <TextField
              fullWidth
              margin="normal"
              label="Confirm Password"
              type={showPassword ? "text" : "password"}
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              required
            />
          )}

          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ 
              mt: 2, 
              mb: 2,
              backgroundColor: blue[700],
              '&:hover': { backgroundColor: blue[800] }
            }}
          >
            {activeTab === 0 ? 'Login' : 'Sign Up'}
          </Button>

          {activeTab === 0 && (
            <Link 
              href="#" 
              variant="body2" 
              sx={{ 
                display: 'block', 
                textAlign: 'center',
                color: blue[700]
              }}
            >
              Forgot Password?
            </Link>
          )}
        </Box>
      </Paper>
    </Container>
  );
};

export default AuthPage;