import React, { useState } from 'react';
import { 
  Card, CardContent, Typography, 
  Table, TableBody, TableCell, 
  TableContainer, TableHead, TableRow, 
  Paper, Button, Dialog, 
  DialogTitle, DialogContent, Grid, 
  Box, Chip, Avatar
} from '@mui/material';
import { 
  DocumentScanner, Group, 
  Percent, 
  Visibility 
} from '@mui/icons-material';
import { blue, green, grey } from '@mui/material/colors';

const Dashboard = () => {
  const [metrics, setMetrics] = useState({
    totalDocuments: 42,
    partiesInvolved: 15,
    activeDocuments: 25,
    expiredDocuments: 17,
    complianceRate: 87.5
  });

  const [documents, setDocuments] = useState([
    {
      id: 1,
      fileName: 'TechCorp_SLA_2024.pdf',
      client: 'TechCorp',
      signingDate: '2024-01-15',
      expirationDate: '2025-01-15',
      status: 'Active',
      complianceRate: 95
    },
    {
      id: 2,
      fileName: 'GlobalServices_Agreement.docx',
      client: 'Global Services Inc',
      signingDate: '2023-11-20',
      expirationDate: '2024-11-20',
      status: 'Under Review',
      complianceRate: 85
    },
    {
      id: 3,
      fileName: 'InnovaTech_Contract.pdf',
      client: 'InnovaTech',
      signingDate: '2024-02-01',
      expirationDate: '2025-02-01',
      status: 'Active',
      complianceRate: 90
    }
  ]);

  const [selectedDocument, setSelectedDocument] = useState(null);
  const [isDocumentModalOpen, setIsDocumentModalOpen] = useState(false);

  const viewDocument = (doc) => {
    setSelectedDocument(doc);
    setIsDocumentModalOpen(true);
  };

  const MetricCard = ({ title, value, icon, color }) => (
    <Card 
      sx={{ 
        height: '90%', 
        display: 'flex', 
        flexDirection: 'column', 
        justifyContent: 'space-between',
        transition: 'transform 0.3s',
        '&:hover': { transform: 'scale(1.05)' }
      }}
      elevation={4}
    >
      <CardContent sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography color="textSecondary" gutterBottom>
            {title}
          </Typography>
          <Typography variant="h5" sx={{ color: color }}>
            {value}
          </Typography>
        </Box>
        <Avatar sx={{ backgroundColor: color, width: 56, height: 56 }}>
          {icon}
        </Avatar>
      </CardContent>
    </Card>
  );

  return (
    <Box sx={{ 
      padding: 3, 
      backgroundColor: grey[50],
      height: '80vh', // Changed to 100vh to remove scrollbar
      overflow: 'hidden' // Prevent overflow
    }}>
      <Typography 
        variant="h4" 
        sx={{ 
          marginBottom: 3, 
          color: blue[700],
          fontWeight: 600 
        }}
      >
        SLA Insights Dashboard
      </Typography>
      
      {/* Metrics Grid */}
      <Grid container spacing={3} sx={{ marginBottom: 3 }}>
        <Grid item xs={12} sm={4}>
          <MetricCard 
            title="Total Documents" 
            value={metrics.totalDocuments} 
            icon={<DocumentScanner />} 
            color={blue[500]} 
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <MetricCard 
            title="Parties Involved" 
            value={metrics.partiesInvolved} 
            icon={<Group />} 
            color={green[500]} 
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <MetricCard 
            title="Active/Expired Documents" 
            value={`${metrics.activeDocuments}/${metrics.expiredDocuments}`} 
            icon={<Percent />} 
            color={blue[700]} 
          />
        </Grid>
      </Grid>

      {/* Documents Table */}
      <Card elevation={4} sx={{ overflowY: 'auto', maxHeight: 'calc(100vh - 300px)' }}>
        <CardContent>
          <Typography 
            variant="h6" 
            sx={{ 
              marginBottom: 2, 
              color: blue[700],
              fontWeight: 600 
            }}
          >
            Document Repository
          </Typography>
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow>
                  {['File Name', 'Client', 'Signing Date', 'Expiration Date', 'Status', 'Compliance %', 'Actions']
                    .map((header) => (
                      <TableCell 
                        key={header} 
                        sx={{ 
                          fontWeight: 'bold', 
                          color: blue[700] 
                        }}
                      >
                        {header}
                      </TableCell>
                    ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {documents.map((doc) => (
                  <TableRow key={doc.id} hover>
                    <TableCell>{doc.fileName}</TableCell>
                    <TableCell>{doc.client}</TableCell>
                    <TableCell>{doc.signingDate}</TableCell>
                    <TableCell>{doc.expirationDate}</TableCell>
                    <TableCell>
                      <Chip 
                        label={doc.status} 
                        color={
                          doc.status === 'Active' ? 'success' : 
                          doc.status === 'Under Review' ? 'warning' : 
                          'error'
                        } 
                        size="small"
                      />
                    </TableCell>
                    <TableCell>{doc.complianceRate}%</TableCell>
                    <TableCell>
                      <Button 
                        variant="outlined" 
                        color="primary" 
                        size="small" 
                        startIcon={<Visibility />}
                        onClick={() => viewDocument(doc)}
                        sx={{ textTransform: 'none' }}
                      >
                        View Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Document Details Dialog */}
      <Dialog 
        open={isDocumentModalOpen} 
        onClose={() => setIsDocumentModalOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle sx={{ backgroundColor: blue[50], color: blue[700] }}>
          Document Details
        </DialogTitle>
        <DialogContent sx={{ padding: 3 }}>
          {selectedDocument && (
            <Grid container spacing={3}>
              {Object.entries(selectedDocument)
                .filter(([key]) => key !== 'id')
                .map(([key, value]) => (
                  <Grid item xs={6} key={key}>
                    <Typography 
                      variant="subtitle1" 
                      sx={{ fontWeight: 600, color: blue[700] }}
                    >
                      {key.replace(/([A-Z])/g, ' $1').replace(/^./, (str) => str.toUpperCase())}:
                    </Typography>
                    <Typography>{value}</Typography>
                  </Grid>
                ))}
            </Grid>
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default Dashboard;