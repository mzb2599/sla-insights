import React, { useState, useRef, useEffect } from 'react';
import { 
  Box, Typography, 
  TextField, Button, 
  Paper, IconButton, 
  Container 
} from '@mui/material';
import { 
  Upload, Send, 
  ChatBubbleOutline 
} from '@mui/icons-material';
import { blue, grey } from '@mui/material/colors';

const Chatbot = () => {
  const [messages, setMessages] = useState([
    {
      type: 'bot',
      content: 'Hello! I\'m your SLA Document Assistant. Upload documents or ask me anything about your service level agreements.'
    }
  ]);
  const [input, setInput] = useState('');
  const fileInputRef = useRef(null);
  const messagesEndRef = useRef(null);

  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    
    const fileMessages = files.map(file => ({
      type: 'system',
      content: `Uploaded: ${file.name}`
    }));

    setMessages(prev => [...prev, ...fileMessages]);
  };

  const triggerFileInput = () => {
    fileInputRef.current.click();
  };

  const sendMessage = () => {
    if (input.trim()) {
      setMessages(prev => [
        ...prev, 
        { type: 'user', content: input },
        { 
          type: 'bot', 
          content: `Analyzing your query: "${input}". Retrieving relevant SLA insights...` 
        }
      ]);
      setInput('');
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  return (
    <Container 
      maxWidth="md" 
      sx={{ 
        height: '100%', 
        display: 'flex', 
        flexDirection: 'column',
        backgroundColor: grey[50],
        padding: 0
      }}
    >
      <Box 
        sx={{ 
          backgroundColor: blue[700], 
          color: 'white', 
          padding: 2, 
          display: 'flex', 
          justifyContent: 'space-between',
          alignItems: 'center'
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <ChatBubbleOutline sx={{ marginRight: 2 }} />
          <Typography variant="h6">
            SLA Document Assistant
          </Typography>
        </Box>
        <input 
          type="file" 
          ref={fileInputRef}
          onChange={handleFileUpload}
          style={{ display: 'none' }} 
          multiple
          accept=".pdf,.docx,.txt"
        />
        <Button 
          variant="contained" 
          color="secondary"
          startIcon={<Upload />} 
          onClick={triggerFileInput}
        >
          Upload
        </Button>
      </Box>

      <Paper 
        sx={{ 
          flexGrow: 1, 
          overflowY: 'auto', 
          padding: 2, 
          margin: 0,
          backgroundColor: grey[50],
          maxHeight: 400
        }}
        elevation={0}
      >
        {messages.map((msg, index) => (
          <Box 
            key={index} 
            sx={{ 
              display: 'flex', 
              justifyContent: msg.type === 'user' ? 'flex-end' : 'flex-start',
              marginBottom: 2
            }}
          >
            <Paper
              sx={{ 
                maxWidth: '75%',
                padding: 1.5,
                backgroundColor: 
                  msg.type === 'user' ? blue[100] : 
                  msg.type === 'bot' ? grey[200] : 
                  grey[100],
                borderRadius: 2
              }}
              elevation={1}
            >
              <Typography 
                variant="body2" 
                sx={{ 
                  color: 
                    msg.type === 'user' ? blue[800] : 
                    msg.type === 'bot' ? 'text.primary' : 
                    'text.secondary'
                }}
              >
                {msg.content}
              </Typography>
            </Paper>
          </Box>
        ))}
        <div ref={messagesEndRef} />
      </Paper>

      <Box 
        sx={{ 
          padding: 2, 
          backgroundColor: 'white',
          borderTop: `1px solid ${grey[300]}`
        }}
      >
        <TextField 
          fullWidth
          variant="outlined"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
          placeholder="Ask about your SLA documents..."
          sx={{ 
            '& .MuiOutlinedInput-root': {
              borderRadius: 3
            }
          }}
          InputProps={{
            endAdornment: (
              <IconButton 
                color="primary" 
                onClick={sendMessage}
                disabled={!input.trim()}
              >
                <Send />
              </IconButton>
            )
          }}
        />
      </Box>
    </Container>
  );
};

export default Chatbot;