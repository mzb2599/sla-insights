import React, { useState } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  IconButton,
  Box,
  Container,
} from "@mui/material";
import { Home as HomeIcon, AccountCircle, Logout } from "@mui/icons-material";

import Dashboard from "./components/Dashboards.tsx";
import Chatbot from "./components/chatbot.tsx";

const App = () => {
  const [activePage, setActivePage] = useState("dashboard");

  const renderPage = () => {
    switch (activePage) {
      case "dashboard":
        return <Dashboard />;
      case "chatbot":
        return <Chatbot />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", height: "100vh" }}>
      <AppBar position="static">
        <Toolbar sx={{ justifyContent: "space-between" }}>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            SLA INSIGHTS
            <Box>
              <Button
                color={activePage === "dashboard" ? "secondary" : "inherit"}
                onClick={() => setActivePage("dashboard")}
              >
                Dashboard
              </Button>
              <Button
                color={activePage === "chatbot" ? "secondary" : "inherit"}
                onClick={() => setActivePage("chatbot")}
              >
                Chatbot
              </Button>
            </Box>
          </Box>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <IconButton color="inherit">
              <AccountCircle />
              <Typography sx={{ marginLeft: 1 }}>John Doe</Typography>
            </IconButton>
            <Button color="inherit" startIcon={<Logout />}>
              Logout
            </Button>
          </Box>
        </Toolbar>
      </AppBar>

      <Container sx={{ flexGrow: 1, overflowY: "auto", padding: 2 }}>
        {renderPage()}
      </Container>
    </Box>
  );
};

export default App;
